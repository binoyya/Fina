<?php
		
require_once 'db.php';
   $stmt = $con->prepare("INSERT INTO customer (name, description, email, dob)
    VALUES (:name, :description, :email, :dob)");
    $stmt->bindParam(':name', $name);
	$stmt->bindParam(':description', $description);
    $stmt->bindParam(':email', $email);
    $stmt->bindParam(':dob', $dob);

    $name=$_POST['name'];
	$description=$_POST['description'];
	$email=$_POST['email'];
	$dob=$_POST['dob'];
	
    $stmt->execute();
header('Location: index.php');
 ?>
