$(document).ready(function () {

    $('#custform').validate({
        rules: {
            name: {
                minlength: 4,
				maxlength: 22,
                required: true
            },
            description: {
                minlength: 7,
				maxlength: 55,
                required: true
            },
            email: {
                required: true,
                email: true
            },
            dob:{
                required: true
            }
        },
        highlight: function (element) {
            $(element).closest('.form-group').removeClass('has-success').addClass('has-error');
        },
        success: function (element) {
            element.text('OK!').addClass('valid')
                .closest('.form-group').removeClass('has-error').addClass('has-success');
        }
    });

});