# preassesment_exercise
customer details page

- On the front end bootstrap is used for markup and jquery for validation of form
- PHP is used as server side to store and retrieve data
- MYSQL is used to store data
- customer.sql can be used to import database which contains all the information and tables for database
