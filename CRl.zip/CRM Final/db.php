<?php
$host='localhost';
$dbname='custdetails';
$username='root';
$password='';
	$con = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
?>	