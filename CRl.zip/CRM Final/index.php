<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">	
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/styles.css">
	<title>Customer Details</title>
</head>
<body>
<div class="container-fluid top">
	<h1>Travel Customer Details</h1>
</div>
<div class="container">
<form class="form-horizontal" role="form" id="custform" method="POST"  action="savecust.php">
    <div class="form-group">
        <label for="name" class="control-label col-xs-2">Name</label>
        <div class="col-xs-8">
        	<input type="text" name="name" class="form-control" id="name" placeholder="name">
        </div>
    </div>
    <div class="form-group">
        <label for="address" class="control-label col-xs-2">Address</label>
        <div class="col-xs-8">
        	<input type="text" name="address" class="form-control" id="address" placeholder="address">
        </div>
    </div>        
    <div class="form-group">
        <label for="home_town" class="control-label col-xs-2">Home Town</label>
        <div class="col-xs-8">
        <input type="home_town" name="home_town" class="form-control" id="home_town" placeholder="home_town">
        </div>
    </div> 
    <div class="form-group">
        <label for="email" class="control-label col-xs-2">Email</label>
        <div class="col-xs-8">
        <input type="email" name="email" class="form-control" id="email" placeholder="email">
        </div>
    </div>
    <div class="form-group">
        <label for="contact_details" class="control-label col-xs-2">Contact Details</label>
        <div class="col-xs-8">
        <input type="contact_details" name="contact_details" class="form-control" id="contact_details" placeholder="contact_details">
        </div>
    </div> 	
     <div class="form-group">
        <label for="passport_id" class="control-label col-xs-2">Passport</label>
        <div class="col-xs-8">
        <input type="passport_id" name="passport_id" class="form-control" id="passport_id" placeholder="passport_id">
        </div>
    </div>
     <div class="form-group">
        <label for="arrival_date" class="control-label col-xs-2">Arrive On</label>
        <div class="col-xs-8">
        <input type="date" name="arrival_date" class="form-control" id="arrival_date" placeholder="">
        </div>
    </div> 
     <div class="form-group">
        <label for="departure_date" class="control-label col-xs-2">Depart On</label>
        <div class="col-xs-8">
        <input type="date" name="departure_date" class="form-control" id="departure_date" placeholder="">
        </div>
    </div>
     <div class="form-group">
        <label for="destination_of_travel" class="control-label col-xs-2">Destination</label>
        <div class="col-xs-8">
        <input type="destination_of_travel" name="destination_of_travel" class="form-control" id="destination_of_travel" placeholder="">
        </div>
    </div>
     <div class="form-group">
        <label for="travel_package" class="control-label col-xs-2">Travel Package</label>
        <div class="col-xs-8">
        <input type="travel_package" name="travel_package" class="form-control" id="travel_package" placeholder="">
        </div>
    </div>
    <div class="form-group">
        <label for="dob" class="control-label col-xs-2">DOB</label>
        <div class="col-xs-8">
        <input type="date" name="dob" class="form-control" id="dob" placeholder="">
        </div>
    </div>
     <div class="form-group">
        <label for="description" class="control-label col-xs-2">Description</label>
        <div class="col-xs-8">
        <input type="description" name="description" class="form-control" id="description" placeholder="">
        </div>
    </div>
    <div class="form-group">
    	<div class="col-xs-offset-8 col-xs-4">
    		<button type="submit" class="btn btn-primary">Save</button>
    	</div>
    </div>
</form>
<h1 id="yo">Customers List</h1>
<div class="table-responsive">
<?php
	require_once 'db.php';
	$res=$con->query("select * from customer");
	$table = '<table  class="table table-bordered">		  
				<tr>
					 <th>ID</th>
					 <th>Name</th>
					 <th>Address</th>
					 <th>Home Town</th>
					 <th>Email</th> 
					 <th>Contact Details</th>
					 <th>Passport</th>
					 <th>Arrive On</th>
					 <th>Depart On</th>
					 <th>Destination</th>
					 <th>Travel Package</th>
					 <th>DOB</th>
					 <th>Description</th>	 
				</tr>';
	while($row=$res->fetch(PDO::FETCH_ASSOC))
		{
			$table = $table."<tr>";
			$table = $table. "<td>".$row['id']."</td>";
			$table = $table. "<td>".$row['name']."</td>";
			$table = $table. "<td>".$row['address']."</td>";
			$table = $table. "<td>".$row['home_town']."</td>";
			$table = $table. "<td>".$row['email']."</td>";
			$table = $table. "<td>".$row['contact_details']."</td>";
			$table = $table. "<td>".$row['passport_id']."</td>";
			$table = $table. "<td>".$row['arrival_date']."</td>";
			$table = $table. "<td>".$row['departure_date']."</td>";
			$table = $table. "<td>".$row['destination_of_travel']."</td>";
			$table = $table. "<td>".$row['travel_package']."</td>";
			$table = $table. "<td>".$row['dob']."</td>";
			$table = $table. "<td>".$row['description']."</td>";
			$table = $table."</tr>";
		}
		echo $table;
?>
</div>
</div>
<script src="js/jquery-3.1.0.min.js"></script>
<script type="text/javascript" src="https://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.js"></script>
<script type="text/javascript" src="js/script.js"></script>
<script src="js/bootstrap.min.js"></script>
</body>
</html>